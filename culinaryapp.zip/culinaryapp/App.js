import React, { useState } from 'react';
import { View, Text, Button, TextInput, FlatList, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

const SplashScreen = ({ navigation }) => (
  <View style={styles.container}>
    <Text style={styles.title}>Christoffel's Culinary Creations</Text>
    <Button title="Click here and dine" color={colors.brown} onPress={() => navigation.navigate('SignIn')} />
  </View>
);

const SignInScreen = ({ navigation }) => (
  <View style={styles.container}>
    <TextInput placeholder="Email" style={styles.input} />
    <TextInput placeholder="Password" secureTextEntry style={styles.input} />
    <Button title="Sign In" color={colors.brown} onPress={() => navigation.navigate('Home')} />
    <Button title="Don't have an account? Sign Up" color={colors.brown} onPress={() => navigation.navigate('SignUp')} />
  </View>
);

const SignUpScreen = ({ navigation }) => (
  <View style={styles.container}>
    <TextInput placeholder="Email" style={styles.input} />
    <TextInput placeholder="Password" secureTextEntry style={styles.input} />
    <Button title="Sign Up" color={colors.brown} onPress={() => navigation.navigate('Home')} />
  </View>
);

const HomeScreen = ({ navigation }) => {
  const [menu, setMenu] = useState([
    { id: '1', name: 'Grilled Salmon', price: 'R120' },
    { id: '2', name: 'Beef Wellington', price: 'R180' },
    { id: '3', name: 'Pasta Primavera', price: 'R95' },
  ]);

  return (
    <View style={styles.container}>
      <Button title="Manage Menu" color={colors.brown} onPress={() => navigation.navigate('Manage', { menu, setMenu })} />
      <FlatList
        data={menu}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('Order', { meal: item })}>
            <Text style={styles.item}>{item.name} - {item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const OrderScreen = ({ route }) => {
  const { meal } = route.params;
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{meal.name}</Text>
      <Text style={styles.price}>Price: {meal.price}</Text>
      <Button title="Place Order" color={colors.brown} onPress={() => Alert.alert('Order Placed', `Your order for ${meal.name} has been placed!`)} />
    </View>
  );
};

const ManageScreen = ({ route, navigation }) => {
  const { menu, setMenu } = route.params;
  const [newDish, setNewDish] = useState('');
  const [newPrice, setNewPrice] = useState('');

  const addDish = () => {
    if (newDish.trim() !== '' && newPrice.trim() !== '') {
      setMenu([...menu, { id: Date.now().toString(), name: newDish, price: newPrice }]);
      setNewDish('');
      setNewPrice('');
    }
  };

  const removeDish = (id) => {
    setMenu(menu.filter(item => item.id !== id));
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="New Dish"
        value={newDish}
        onChangeText={setNewDish}
        style={styles.input}
      />
      <TextInput
        placeholder="Price (e.g. R100)"
        value={newPrice}
        onChangeText={setNewPrice}
        style={styles.input}
      />
      <Button title="Add Dish" color={colors.brown} onPress={addDish} />
      <FlatList
        data={menu}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.listItem}>
            <Text style={styles.item}>{item.name} - {item.price}</Text>
            <Button title="Remove" color={colors.brown} onPress={() => removeDish(item.id)} />
          </View>
        )}
      />
    </View>
  );
};

const App = () => (
  <NavigationContainer>
    <Stack.Navigator initialRouteName="Splash">
      <Stack.Screen name="Splash" component={SplashScreen} options={{ headerShown: false }} />
      <Stack.Screen name="SignIn" component={SignInScreen} />
      <Stack.Screen name="SignUp" component={SignUpScreen} />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Order" component={OrderScreen} />
      <Stack.Screen name="Manage" component={ManageScreen} />
    </Stack.Navigator>
  </NavigationContainer>
);

const colors = {
  lightBrown: '#f5e1c9',
  brown: '#8b4513'
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.lightBrown,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: colors.brown,
    marginBottom: 20,
    textAlign: 'center',
  },
  price: {
    fontSize: 18,
    color: colors.brown,
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.brown,
    padding: 10,
    width: '100%',
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  item: {
    padding: 15,
    fontSize: 18,
    backgroundColor: '#fff8f0',
    borderBottomWidth: 1,
    borderColor: colors.brown,
    width: '100%',
    textAlign: 'center',
    color: colors.brown,
  },
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff8f0',
    marginVertical: 5,
    padding: 10,
    width: '100%',
  },
});

export default App;

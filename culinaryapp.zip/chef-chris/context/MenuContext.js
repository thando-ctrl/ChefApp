import React, { createContext, useState } from 'react';

export const MenuContext = createContext();

export const MenuProvider = ({ children }) => {
  const [menuItems, setMenuItems] = useState([
    {
      id: '1',
      name: 'Garlic Bread',
      course: 'Starter',
      price: 45.99,
      ingredients: 'Fresh bread, garlic butter, parsley'
    },
    {
      id: '2',
      name: 'Caprese Salad',
      course: 'Starter',
      price: 65.50,
      ingredients: 'Tomatoes, mozzarella, basil'
    },
    {
      id: '3',
      name: 'Ribeye Steak',
      course: 'Main',
      price: 189.99,
      ingredients: '300g ribeye, veggies'
    },
    {
      id: '4',
      name: 'Chocolate Lava Cake',
      course: 'Dessert',
      price: 75.00,
      ingredients: 'Dark chocolate, ice cream'
    }
  ]);

  const addMenuItem = (item) => {
    setMenuItems([...menuItems, {
      id: Date.now().toString(),
      ...item,
      price: parseFloat(item.price)
    }]);
  };

  const removeMenuItem = (id) => {
    setMenuItems(menuItems.filter(item => item.id !== id));
  };

  return (
    <MenuContext.Provider value={{ menuItems, addMenuItem, removeMenuItem }}>
      {children}
    </MenuContext.Provider>
  );
};
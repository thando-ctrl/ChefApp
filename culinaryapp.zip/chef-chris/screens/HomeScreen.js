import React from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';

const foodItems = [
  { id: '1', name: 'Bruschetta', category: 'Starter', price: 45, description: 'Toasted bread topped with tomatoes, garlic, and fresh basil.' },
  { id: '2', name: 'Caprese Salad', category: 'Starter', price: 55, description: 'Fresh mozzarella, tomatoes, and sweet basil.' },
  { id: '3', name: 'Filet Mignon', category: 'Main', price: 220, description: 'Premium cut beef with red wine reduction.' },
  { id: '4', name: 'Tiramisu', category: 'Dessert', price: 75, description: 'Classic Italian dessert with coffee-soaked ladyfingers.' },
];

const HomeScreen = ({ navigation }) => {
  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.itemContainer}
      onPress={() => navigation.navigate('FoodDetails', { foodItem: item })}
    >
      <View style={styles.itemTextContainer}>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemCategory}>{item.category}</Text>
      </View>
      <Text style={styles.itemPrice}>R{item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.manageButton}
        onPress={() => navigation.navigate('ManageMenu')}
      >
        <Text style={styles.manageButtonText}>Manage Menu</Text>
      </TouchableOpacity>
      
      <FlatList
        data={foodItems}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EFEBE9',
  },
  manageButton: {
    backgroundColor: '#5D4037',
    padding: 15,
    margin: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  manageButtonText: {
    color: '#EFEBE9',
    fontSize: 16,
    fontWeight: 'bold',
  },
  listContainer: {
    padding: 10,
  },
  itemContainer: {
    backgroundColor: '#D7CCC8',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemTextContainer: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 5,
  },
  itemCategory: {
    fontSize: 14,
    color: '#5D4037',
    fontStyle: 'italic',
  },
  itemPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4E342E',
  },
});

export default HomeScreen;
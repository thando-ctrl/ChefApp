import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const FoodDetailsScreen = ({ route, navigation }) => {
  const { foodItem } = route.params;

  return (
    <View style={styles.container}>
      <View style={styles.detailsContainer}>
        <Text style={styles.name}>{foodItem.name}</Text>
        <Text style={styles.category}>{foodItem.category}</Text>
        <Text style={styles.price}>R{foodItem.price}</Text>
        <Text style={styles.description}>{foodItem.description}</Text>
      </View>
      
      <TouchableOpacity style={styles.orderButton}>
        <Text style={styles.orderButtonText}>Place Order</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EFEBE9',
    padding: 20,
  },
  detailsContainer: {
    backgroundColor: '#D7CCC8',
    padding: 20,
    borderRadius: 5,
    marginBottom: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 5,
  },
  category: {
    fontSize: 16,
    color: '#5D4037',
    fontStyle: 'italic',
    marginBottom: 10,
  },
  price: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4E342E',
    marginBottom: 15,
  },
  description: {
    fontSize: 16,
    color: '#5D4037',
    lineHeight: 24,
  },
  orderButton: {
    backgroundColor: '#5D4037',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 20,
  },
  orderButtonText: {
    color: '#EFEBE9',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default FoodDetailsScreen;
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';

const ManageMenuScreen = ({ navigation }) => {
  const [foodItems, setFoodItems] = useState([
    { id: '1', name: 'Bruschetta', category: 'Starter', price: '45' },
    { id: '2', name: 'Caprese Salad', category: 'Starter', price: '55' },
    { id: '3', name: 'Filet Mignon', category: 'Main', price: '220' },
    { id: '4', name: 'Tiramisu', category: 'Dessert', price: '75' },
  ]);
  
  const [newItem, setNewItem] = useState({
    name: '',
    category: 'Starter',
    price: '',
  });

  const handleAddItem = () => {
    if (newItem.name && newItem.price) {
      setFoodItems([...foodItems, {
        id: Date.now().toString(),
        ...newItem
      }]);
      setNewItem({
        name: '',
        category: 'Starter',
        price: '',
      });
    }
  };

  const handleRemoveItem = (id) => {
    setFoodItems(foodItems.filter(item => item.id !== id));
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemTextContainer}>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemCategory}>{item.category}</Text>
        <Text style={styles.itemPrice}>R{item.price}</Text>
      </View>
      <TouchableOpacity 
        style={styles.removeButton}
        onPress={() => handleRemoveItem(item.id)}
      >
        <Text style={styles.removeButtonText}>Remove</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.addItemContainer}>
        <Text style={styles.sectionTitle}>Add New Item</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Item Name"
          value={newItem.name}
          onChangeText={text => setNewItem({...newItem, name: text})}
          placeholderTextColor="#BCAAA4"
        />
        
        <TextInput
          style={styles.input}
          placeholder="Price (R)"
          value={newItem.price}
          onChangeText={text => setNewItem({...newItem, price: text})}
          keyboardType="numeric"
          placeholderTextColor="#BCAAA4"
        />
        
        <View style={styles.categoryContainer}>
          <Text style={styles.categoryLabel}>Category:</Text>
          <TouchableOpacity 
            style={[styles.categoryButton, newItem.category === 'Starter' && styles.categoryButtonSelected]}
            onPress={() => setNewItem({...newItem, category: 'Starter'})}
          >
            <Text style={newItem.category === 'Starter' ? styles.categoryButtonTextSelected : styles.categoryButtonText}>Starter</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.categoryButton, newItem.category === 'Main' && styles.categoryButtonSelected]}
            onPress={() => setNewItem({...newItem, category: 'Main'})}
          >
            <Text style={newItem.category === 'Main' ? styles.categoryButtonTextSelected : styles.categoryButtonText}>Main</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.categoryButton, newItem.category === 'Dessert' && styles.categoryButtonSelected]}
            onPress={() => setNewItem({...newItem, category: 'Dessert'})}
          >
            <Text style={newItem.category === 'Dessert' ? styles.categoryButtonTextSelected : styles.categoryButtonText}>Dessert</Text>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity style={styles.addButton} onPress={handleAddItem}>
          <Text style={styles.addButtonText}>Add Item</Text>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.sectionTitle}>Current Menu</Text>
      <FlatList
        data={foodItems}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EFEBE9',
    padding: 15,
  },
  addItemContainer: {
    backgroundColor: '#D7CCC8',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#5D4037',
    marginBottom: 15,
  },
  input: {
    height: 40,
    borderColor: '#A1887F',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingLeft: 10,
    color: '#5D4037',
  },
  categoryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    flexWrap: 'wrap',
  },
  categoryLabel: {
    marginRight: 10,
    color: '#5D4037',
  },
  categoryButton: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#A1887F',
    marginRight: 5,
    marginBottom: 5,
  },
  categoryButtonSelected: {
    backgroundColor: '#5D4037',
    borderColor: '#5D4037',
  },
  categoryButtonText: {
    color: '#5D4037',
  },
  categoryButtonTextSelected: {
    color: '#EFEBE9',
  },
  addButton: {
    backgroundColor: '#5D4037',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#EFEBE9',
    fontWeight: 'bold',
  },
  listContainer: {
    paddingBottom: 20,
  },
  itemContainer: {
    backgroundColor: '#D7CCC8',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemTextContainer: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 5,
  },
  itemCategory: {
    fontSize: 14,
    color: '#5D4037',
    fontStyle: 'italic',
    marginBottom: 5,
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4E342E',
  },
  removeButton: {
    backgroundColor: '#8D6E63',
    padding: 8,
    borderRadius: 5,
    marginLeft: 10,
  },
  removeButtonText: {
    color: '#EFEBE9',
    fontSize: 14,
  },
});

export default ManageMenuScreen;
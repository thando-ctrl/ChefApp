import React, { useEffect } from 'react';
import { View, Text, StyleSheet, StatusBar } from 'react-native';

const SplashScreen = ({ navigation }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('SignIn');
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigation]); // Fixed by adding navigation to dependencies

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#4E342E" barStyle="light-content" />
      <Text style={styles.title}>Gourmet Chef</Text>
      <Text style={styles.subtitle}>Premium Dining Experience</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#5D4037',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#EFEBE9',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    color: '#D7CCC8',
  },
});

export default SplashScreen;